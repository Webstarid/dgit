# Template for a full-text request on ResearchGate

Dear XXX,

First of all, thank you for your interest in my work!

I do not upload my work to ResearchGate because they are a for-profit organization. They have the practice of sometimes inserting advertisement into the uploaded PDFs. I find this unacceptable.

I keep a copy of all my works on my website: http://www.leouieda.com/

There you will also find links to related works and other resources like source code, presentations, data, etc.

The paper you have asked for is at:

*Optional*:
The article you have requested is open-access (https://en.wikipedia.org/wiki/Open_access) and can also be freely downloaded from the publishers site:

Best regards,

Leonardo
